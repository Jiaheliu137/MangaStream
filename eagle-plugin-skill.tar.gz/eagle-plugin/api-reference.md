# Eagle Plugin API Reference

Complete reference for Eagle Plugin API methods and objects.

## Table of Contents

1. [Item API](#item-api)
2. [Folder API](#folder-api)
3. [Tag API](#tag-api)
4. [Library API](#library-api)
5. [Window API](#window-api)
6. [Dialog API](#dialog-api)
7. [Notification API](#notification-api)
8. [Context Menu API](#context-menu-api)
9. [Clipboard API](#clipboard-api)
10. [App API](#app-api)
11. [Event API](#event-api)
12. [Log API](#log-api)
13. [OS & System APIs](#os--system-apis)

---

## Item API

Manage and access items (files) in Eagle.

### eagle.item.getSelected()

Get currently selected items.

```javascript
eagle.item.getSelected().then(items => {
  console.log(items); // Array of item objects
});
```

**Returns:** `Promise<Item[]>`

### Item Object Structure

```javascript
{
  id: "LJEL9VABCDEF",           // Unique item ID
  name: "image.jpg",            // File name
  ext: "jpg",                   // File extension
  size: 1024000,                // File size in bytes
  filePath: "/path/to/file",    // Full file path
  url: "file:///path/to/file",  // File URL
  tags: ["tag1", "tag2"],       // Array of tags
  folders: ["folder-id"],       // Parent folder IDs
  width: 1920,                  // Image width (for images)
  height: 1080,                 // Image height (for images)
  annotation: "Note...",        // Item annotation
  rating: 5,                    // Rating (0-5)
  modificationTime: 1234567890, // Last modified timestamp
  // ... more fields
}
```

### eagle.item.get(id)

Get specific item by ID.

```javascript
const item = await eagle.item.get("LJEL9VABCDEF");
```

**Parameters:**
- `id` (string): Item ID

**Returns:** `Promise<Item>`

### eagle.item.getAll()

Get all items in current library.

```javascript
const allItems = await eagle.item.getAll();
```

**Returns:** `Promise<Item[]>`

---

## Folder API

Work with folders in Eagle library.

### eagle.folder.get(id)

Get folder by ID.

```javascript
const folder = await eagle.folder.get("folder-id");
```

**Returns:** `Promise<Folder>`

### eagle.folder.getAll()

Get all folders.

```javascript
const folders = await eagle.folder.getAll();
```

**Returns:** `Promise<Folder[]>`

### Folder Object Structure

```javascript
{
  id: "folder-id",
  name: "My Folder",
  description: "Folder description",
  children: [],              // Child folder IDs
  modificationTime: 1234567890,
  // ... more fields
}
```

---

## Tag API

Manage tags.

### eagle.tag.getAll()

Get all tags in library.

```javascript
const tags = await eagle.tag.getAll();
```

**Returns:** `Promise<Tag[]>`

### Tag Object Structure

```javascript
{
  id: "tag-id",
  name: "TagName",
  color: "#FF0000"
}
```

---

## Library API

Access library information.

### eagle.library.get()

Get current library information.

```javascript
const library = await eagle.library.get();
console.log(library.name);
console.log(library.path);
```

**Returns:** `Promise<Library>`

### Library Object Structure

```javascript
{
  id: "library-id",
  name: "My Library",
  path: "/path/to/library",
  // ... more fields
}
```

---

## Window API

Control plugin window.

### eagle.window.close()

Close the plugin window.

```javascript
eagle.window.close();
```

### eagle.window.resize(width, height)

Resize plugin window.

```javascript
eagle.window.resize(800, 600);
```

**Parameters:**
- `width` (number): Window width in pixels
- `height` (number): Window height in pixels

### eagle.window.setPosition(x, y)

Set window position.

```javascript
eagle.window.setPosition(100, 100);
```

**Parameters:**
- `x` (number): X coordinate
- `y` (number): Y coordinate

### eagle.window.center()

Center the window on screen.

```javascript
eagle.window.center();
```

### eagle.window.setAlwaysOnTop(flag)

Set window always on top.

```javascript
eagle.window.setAlwaysOnTop(true);
```

**Parameters:**
- `flag` (boolean): True to keep window on top

---

## Dialog API

Show system dialogs.

### eagle.dialog.showMessageBox(options)

Show message box dialog.

```javascript
const result = await eagle.dialog.showMessageBox({
  type: 'question',
  title: 'Confirm',
  message: 'Are you sure?',
  buttons: ['Yes', 'No'],
  defaultId: 0
});

console.log(result.response); // Index of clicked button
```

**Options:**
- `type`: 'none' | 'info' | 'error' | 'question' | 'warning'
- `title`: Dialog title
- `message`: Message text
- `buttons`: Array of button labels
- `defaultId`: Index of default button

**Returns:** `Promise<{response: number}>`

### eagle.dialog.showOpenDialog(options)

Show file open dialog.

```javascript
const result = await eagle.dialog.showOpenDialog({
  title: 'Select File',
  properties: ['openFile', 'multiSelections'],
  filters: [
    { name: 'Images', extensions: ['jpg', 'png', 'gif'] },
    { name: 'All Files', extensions: ['*'] }
  ]
});

console.log(result.filePaths); // Array of selected file paths
```

**Options:**
- `title`: Dialog title
- `defaultPath`: Default directory
- `properties`: Array of 'openFile' | 'openDirectory' | 'multiSelections' | 'showHiddenFiles'
- `filters`: File type filters

**Returns:** `Promise<{filePaths: string[]}>`

### eagle.dialog.showSaveDialog(options)

Show file save dialog.

```javascript
const result = await eagle.dialog.showSaveDialog({
  title: 'Save File',
  defaultPath: 'output.json',
  filters: [
    { name: 'JSON', extensions: ['json'] }
  ]
});

console.log(result.filePath); // Selected save path
```

**Returns:** `Promise<{filePath: string}>`

---

## Notification API

Display notifications.

### eagle.notification.show(options)

Show notification to user.

```javascript
eagle.notification.show({
  title: 'Success',
  message: 'Operation completed successfully',
  type: 'success',
  duration: 3000
});
```

**Options:**
- `title` (string): Notification title (optional)
- `message` (string): Notification message
- `type`: 'info' | 'success' | 'warning' | 'error'
- `duration` (number): Display duration in milliseconds (default: 3000)

---

## Context Menu API

Create context menus.

### eagle.contextMenu.show(items)

Show context menu.

```javascript
eagle.contextMenu.show([
  {
    label: 'Option 1',
    click: () => console.log('Option 1 clicked')
  },
  { type: 'separator' },
  {
    label: 'Option 2',
    enabled: true,
    click: () => console.log('Option 2 clicked')
  }
]);
```

**Menu Item:**
- `label` (string): Menu item text
- `click` (function): Click handler
- `enabled` (boolean): Whether enabled (default: true)
- `type`: 'normal' | 'separator' | 'checkbox'
- `checked` (boolean): For checkbox items

---

## Clipboard API

Clipboard operations.

### eagle.clipboard.writeText(text)

Write text to clipboard.

```javascript
eagle.clipboard.writeText('Hello World');
```

### eagle.clipboard.readText()

Read text from clipboard.

```javascript
const text = eagle.clipboard.readText();
console.log(text);
```

**Returns:** `string`

### eagle.clipboard.writeImage(path)

Write image to clipboard.

```javascript
eagle.clipboard.writeImage('/path/to/image.png');
```

---

## App API

Application information and control.

### eagle.app.getVersion()

Get Eagle version.

```javascript
const version = eagle.app.getVersion();
console.log(version); // e.g., "3.0.0"
```

**Returns:** `string`

### eagle.app.getLocale()

Get current language.

```javascript
const locale = eagle.app.getLocale();
console.log(locale); // e.g., "zh-CN", "en"
```

**Returns:** `string`

### eagle.app.openURL(url)

Open URL in default browser.

```javascript
eagle.app.openURL('https://example.com');
```

---

## Event API

Handle events.

### eagle.event.on(eventName, callback)

Register event listener.

```javascript
eagle.event.on('selectionChanged', (items) => {
  console.log('Selection changed:', items);
});
```

**Common Events:**
- `selectionChanged`: Item selection changed
- `libraryChanged`: Library switched
- `itemAdded`: New item added
- `itemDeleted`: Item deleted
- `itemUpdated`: Item modified

### eagle.event.off(eventName, callback)

Remove event listener.

```javascript
function handler(items) {
  console.log(items);
}

eagle.event.on('selectionChanged', handler);
// Later...
eagle.event.off('selectionChanged', handler);
```

---

## Log API

Logging utilities.

### eagle.log.debug(message, ...args)

Log debug message.

```javascript
eagle.log.debug('Debug info:', data);
```

### eagle.log.info(message, ...args)

Log info message.

```javascript
eagle.log.info('Operation started');
```

### eagle.log.warn(message, ...args)

Log warning.

```javascript
eagle.log.warn('Warning:', warningMessage);
```

### eagle.log.error(message, ...args)

Log error.

```javascript
eagle.log.error('Error occurred:', error);
```

---

## OS & System APIs

### eagle.os.platform()

Get operating system platform.

```javascript
const platform = eagle.os.platform();
// Returns: 'darwin' | 'win32' | 'linux'
```

### eagle.os.homedir()

Get user home directory.

```javascript
const home = eagle.os.homedir();
```

### eagle.screen.getPrimaryDisplay()

Get primary display info.

```javascript
const display = eagle.screen.getPrimaryDisplay();
console.log(display.size.width, display.size.height);
```

### eagle.shell.showItemInFolder(path)

Show file in system file explorer.

```javascript
eagle.shell.showItemInFolder('/path/to/file');
```

### eagle.shell.openPath(path)

Open file or directory with default application.

```javascript
eagle.shell.openPath('/path/to/file.pdf');
```

---

## Type Definitions

### Item Type

```typescript
interface Item {
  id: string;
  name: string;
  ext: string;
  size: number;
  filePath: string;
  url: string;
  tags: string[];
  folders: string[];
  width?: number;
  height?: number;
  annotation?: string;
  rating?: number;
  modificationTime: number;
  // ... additional fields
}
```

### Folder Type

```typescript
interface Folder {
  id: string;
  name: string;
  description?: string;
  children: string[];
  modificationTime: number;
}
```

### Library Type

```typescript
interface Library {
  id: string;
  name: string;
  path: string;
}
```

---

## Error Handling

Always wrap API calls in try-catch:

```javascript
try {
  const items = await eagle.item.getSelected();
  // Process items
} catch (error) {
  eagle.log.error('Failed to get items:', error);
  eagle.notification.show({
    title: 'Error',
    message: error.message,
    type: 'error'
  });
}
```

## Performance Tips

1. **Cache API results**: Don't repeatedly call the same API
2. **Use batch operations**: Process items in batches
3. **Debounce events**: Limit event handler frequency
4. **Lazy load**: Only load data when needed
5. **Clean up listeners**: Remove event listeners when done
