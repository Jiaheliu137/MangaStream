# Eagle Plugin Examples

Complete code examples for common Eagle plugin scenarios.

## Table of Contents

1. [Basic Window Plugin](#basic-window-plugin)
2. [Image Batch Processor](#image-batch-processor)
3. [Tag Manager](#tag-manager)
4. [Export to JSON](#export-to-json)
5. [Folder Organizer](#folder-organizer)
6. [Custom Viewer](#custom-viewer)
7. [Background Service](#background-service)
8. [Internationalization](#internationalization)

---

## Basic Window Plugin

A simple plugin that displays selected items.

### manifest.json

```json
{
  "id": "basic-viewer",
  "name": "Basic Viewer",
  "version": "1.0.0",
  "description": "Display selected items information",
  "author": "Your Name",
  "main": "index.html",
  "type": "window",
  "keywords": ["viewer", "info"]
}
```

### index.html

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Basic Viewer</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      padding: 20px;
      margin: 0;
    }
    .item {
      border: 1px solid #ddd;
      padding: 10px;
      margin: 10px 0;
      border-radius: 4px;
    }
    .item h3 {
      margin: 0 0 10px 0;
    }
  </style>
</head>
<body>
  <h1>Selected Items</h1>
  <div id="items-container"></div>

  <script>
    async function loadItems() {
      try {
        const items = await eagle.item.getSelected();

        if (items.length === 0) {
          document.getElementById('items-container').innerHTML =
            '<p>No items selected</p>';
          return;
        }

        const container = document.getElementById('items-container');
        container.innerHTML = items.map(item => `
          <div class="item">
            <h3>${item.name}</h3>
            <p>Type: ${item.ext.toUpperCase()}</p>
            <p>Size: ${(item.size / 1024).toFixed(2)} KB</p>
            <p>Tags: ${item.tags.join(', ') || 'None'}</p>
          </div>
        `).join('');

      } catch (error) {
        eagle.log.error('Failed to load items:', error);
        eagle.notification.show({
          title: 'Error',
          message: error.message,
          type: 'error'
        });
      }
    }

    // Load items when plugin opens
    loadItems();
  </script>
</body>
</html>
```

---

## Image Batch Processor

Process selected images with resize, rename, or filter operations.

### index.html

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Image Batch Processor</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      max-width: 600px;
    }
    button {
      padding: 10px 20px;
      margin: 5px;
      cursor: pointer;
      background: #007AFF;
      color: white;
      border: none;
      border-radius: 4px;
    }
    button:hover {
      background: #0056b3;
    }
    #status {
      margin-top: 20px;
      padding: 10px;
      background: #f0f0f0;
      border-radius: 4px;
    }
  </style>
</head>
<body>
  <h1>Image Batch Processor</h1>

  <div>
    <button onclick="filterLargeImages()">Filter Large Images (&gt;1MB)</button>
    <button onclick="exportImageInfo()">Export Image Info</button>
    <button onclick="addTagsToAll()">Add Tag to All</button>
  </div>

  <div id="status"></div>

  <script>
    const fs = require('fs');
    const path = require('path');

    function setStatus(message, type = 'info') {
      const status = document.getElementById('status');
      status.innerHTML = `<strong>${type.toUpperCase()}:</strong> ${message}`;
    }

    async function filterLargeImages() {
      try {
        const items = await eagle.item.getSelected();
        const largeImages = items.filter(item => {
          // Filter images over 1MB
          return item.ext.match(/\.(jpg|jpeg|png|gif)$/i) && item.size > 1024 * 1024;
        });

        setStatus(`Found ${largeImages.length} images larger than 1MB`);

        largeImages.forEach(img => {
          eagle.log.info(`Large image: ${img.name} (${(img.size / 1024 / 1024).toFixed(2)} MB)`);
        });

        eagle.notification.show({
          message: `Found ${largeImages.length} large images`,
          type: 'success'
        });

      } catch (error) {
        eagle.log.error('Error:', error);
        setStatus(error.message, 'error');
      }
    }

    async function exportImageInfo() {
      try {
        const items = await eagle.item.getSelected();

        const imageInfo = items
          .filter(item => item.ext.match(/\.(jpg|jpeg|png|gif)$/i))
          .map(item => ({
            name: item.name,
            size: item.size,
            width: item.width,
            height: item.height,
            tags: item.tags,
            path: item.filePath
          }));

        // Show save dialog
        const result = await eagle.dialog.showSaveDialog({
          title: 'Export Image Info',
          defaultPath: 'image-info.json',
          filters: [
            { name: 'JSON', extensions: ['json'] }
          ]
        });

        if (result.filePath) {
          fs.writeFileSync(result.filePath, JSON.stringify(imageInfo, null, 2));
          setStatus(`Exported ${imageInfo.length} images to ${result.filePath}`);

          eagle.notification.show({
            title: 'Export Complete',
            message: `Saved to ${path.basename(result.filePath)}`,
            type: 'success'
          });
        }

      } catch (error) {
        eagle.log.error('Export error:', error);
        setStatus(error.message, 'error');
      }
    }

    async function addTagsToAll() {
      try {
        const items = await eagle.item.getSelected();

        if (items.length === 0) {
          eagle.notification.show({
            message: 'No items selected',
            type: 'warning'
          });
          return;
        }

        // Note: Actual tag adding would require Eagle's tag API
        // This is a demonstration of the workflow
        setStatus(`Would add tags to ${items.length} items`);

        eagle.notification.show({
          message: `Processed ${items.length} items`,
          type: 'success'
        });

      } catch (error) {
        eagle.log.error('Error:', error);
        setStatus(error.message, 'error');
      }
    }
  </script>
</body>
</html>
```

---

## Tag Manager

Manage tags across selected items.

### index.html

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Tag Manager</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
    }
    .tag-list {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin: 10px 0;
    }
    .tag {
      background: #e0e0e0;
      padding: 5px 10px;
      border-radius: 12px;
      font-size: 14px;
    }
    input {
      padding: 8px;
      width: 200px;
      margin-right: 10px;
    }
    button {
      padding: 8px 16px;
      background: #007AFF;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <h1>Tag Manager</h1>

  <div>
    <h2>All Tags in Library</h2>
    <div id="all-tags" class="tag-list"></div>
  </div>

  <div>
    <h2>Tags in Selected Items</h2>
    <div id="selected-tags" class="tag-list"></div>
  </div>

  <div style="margin-top: 20px;">
    <input type="text" id="search-tag" placeholder="Search tags...">
    <button onclick="searchTags()">Search</button>
  </div>

  <div id="search-results"></div>

  <script>
    async function loadAllTags() {
      try {
        const tags = await eagle.tag.getAll();
        const container = document.getElementById('all-tags');

        container.innerHTML = tags.map(tag => `
          <div class="tag" style="background-color: ${tag.color}20;">
            ${tag.name}
          </div>
        `).join('');

      } catch (error) {
        eagle.log.error('Failed to load tags:', error);
      }
    }

    async function loadSelectedTags() {
      try {
        const items = await eagle.item.getSelected();
        const tagSet = new Set();

        items.forEach(item => {
          item.tags.forEach(tag => tagSet.add(tag));
        });

        const container = document.getElementById('selected-tags');
        container.innerHTML = Array.from(tagSet).map(tag => `
          <div class="tag">${tag}</div>
        `).join('');

      } catch (error) {
        eagle.log.error('Failed to load selected tags:', error);
      }
    }

    async function searchTags() {
      const query = document.getElementById('search-tag').value.toLowerCase();

      if (!query) {
        document.getElementById('search-results').innerHTML = '';
        return;
      }

      try {
        const tags = await eagle.tag.getAll();
        const filtered = tags.filter(tag =>
          tag.name.toLowerCase().includes(query)
        );

        document.getElementById('search-results').innerHTML = `
          <h3>Search Results (${filtered.length})</h3>
          <div class="tag-list">
            ${filtered.map(tag => `
              <div class="tag" style="background-color: ${tag.color}20;">
                ${tag.name}
              </div>
            `).join('')}
          </div>
        `;

      } catch (error) {
        eagle.log.error('Search error:', error);
      }
    }

    // Load data on startup
    loadAllTags();
    loadSelectedTags();

    // Refresh when selection changes
    eagle.event.on('selectionChanged', loadSelectedTags);
  </script>
</body>
</html>
```

---

## Export to JSON

Export selected items to JSON with custom formatting.

### main.js

```javascript
const fs = require('fs');
const path = require('path');

async function exportToJSON() {
  try {
    // Get selected items
    const items = await eagle.item.getSelected();

    if (items.length === 0) {
      eagle.notification.show({
        message: 'No items selected',
        type: 'warning'
      });
      return;
    }

    // Format data
    const exportData = {
      exportDate: new Date().toISOString(),
      itemCount: items.length,
      items: items.map(item => ({
        id: item.id,
        name: item.name,
        extension: item.ext,
        size: item.size,
        dimensions: item.width && item.height ? {
          width: item.width,
          height: item.height
        } : null,
        tags: item.tags,
        rating: item.rating,
        annotation: item.annotation,
        filePath: item.filePath,
        modifiedAt: new Date(item.modificationTime).toISOString()
      }))
    };

    // Show save dialog
    const result = await eagle.dialog.showSaveDialog({
      title: 'Export Items to JSON',
      defaultPath: `eagle-export-${Date.now()}.json`,
      filters: [
        { name: 'JSON Files', extensions: ['json'] },
        { name: 'All Files', extensions: ['*'] }
      ]
    });

    if (result.filePath) {
      // Write file
      fs.writeFileSync(
        result.filePath,
        JSON.stringify(exportData, null, 2),
        'utf8'
      );

      eagle.log.info(`Exported ${items.length} items to ${result.filePath}`);

      eagle.notification.show({
        title: 'Export Successful',
        message: `Exported ${items.length} items`,
        type: 'success',
        duration: 3000
      });

      // Ask if user wants to open the file
      const openResult = await eagle.dialog.showMessageBox({
        type: 'question',
        message: 'Export complete. Open the file?',
        buttons: ['Open', 'Close']
      });

      if (openResult.response === 0) {
        eagle.shell.openPath(result.filePath);
      }
    }

  } catch (error) {
    eagle.log.error('Export failed:', error);
    eagle.notification.show({
      title: 'Export Failed',
      message: error.message,
      type: 'error'
    });
  }
}

// Call the function
exportToJSON();
```

---

## Folder Organizer

Organize items by folder structure.

### index.html

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Folder Organizer</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
    }
    .folder {
      margin: 10px 0;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    .folder-name {
      font-weight: bold;
      font-size: 16px;
      margin-bottom: 5px;
    }
    .folder-stats {
      color: #666;
      font-size: 14px;
    }
    button {
      padding: 10px 20px;
      margin: 10px 0;
      background: #007AFF;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <h1>Folder Organizer</h1>

  <button onclick="loadFolders()">Refresh Folders</button>

  <div id="folders-container"></div>

  <script>
    async function loadFolders() {
      try {
        const folders = await eagle.folder.getAll();
        const items = await eagle.item.getAll();

        // Count items per folder
        const folderItemCount = {};
        items.forEach(item => {
          item.folders.forEach(folderId => {
            folderItemCount[folderId] = (folderItemCount[folderId] || 0) + 1;
          });
        });

        // Display folders
        const container = document.getElementById('folders-container');
        container.innerHTML = folders.map(folder => {
          const itemCount = folderItemCount[folder.id] || 0;
          const childCount = folder.children ? folder.children.length : 0;

          return `
            <div class="folder">
              <div class="folder-name">${folder.name}</div>
              <div class="folder-stats">
                Items: ${itemCount} | Subfolders: ${childCount}
              </div>
              ${folder.description ? `<p>${folder.description}</p>` : ''}
            </div>
          `;
        }).join('');

        eagle.notification.show({
          message: `Loaded ${folders.length} folders`,
          type: 'success'
        });

      } catch (error) {
        eagle.log.error('Failed to load folders:', error);
        eagle.notification.show({
          title: 'Error',
          message: error.message,
          type: 'error'
        });
      }
    }

    // Load on startup
    loadFolders();

    // Listen for library changes
    eagle.event.on('libraryChanged', () => {
      eagle.log.info('Library changed, reloading folders...');
      loadFolders();
    });
  </script>
</body>
</html>
```

---

## Custom Viewer

A custom viewer similar to the MangaStream plugin.

### index.html

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Custom Viewer</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      background: #1a1a1a;
      overflow-y: scroll;
      overflow-x: hidden;
    }

    #container {
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }

    .image-wrapper {
      margin: 0 0 2px 0;
      text-align: center;
    }

    .image-wrapper img {
      width: 100%;
      height: auto;
      display: block;
    }

    #controls {
      position: fixed;
      top: 10px;
      right: 10px;
      background: rgba(0, 0, 0, 0.7);
      padding: 10px;
      border-radius: 4px;
      color: white;
      z-index: 1000;
    }

    button {
      padding: 5px 10px;
      margin: 2px;
      background: #007AFF;
      color: white;
      border: none;
      border-radius: 3px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div id="controls">
    <div id="progress">Loading...</div>
    <button onclick="zoomIn()">Zoom In</button>
    <button onclick="zoomOut()">Zoom Out</button>
    <button onclick="resetZoom()">Reset</button>
  </div>

  <div id="container"></div>

  <script>
    let currentZoom = 100;

    async function loadImages() {
      try {
        const items = await eagle.item.getSelected();

        // Filter for images only
        const images = items.filter(item =>
          item.ext.match(/\.(jpg|jpeg|png|gif|webp)$/i)
        );

        if (images.length === 0) {
          document.getElementById('container').innerHTML =
            '<p style="color: white; text-align: center; margin-top: 50px;">No images selected</p>';
          return;
        }

        // Display images
        const container = document.getElementById('container');
        container.innerHTML = images.map((img, index) => `
          <div class="image-wrapper">
            <img src="${img.url}" alt="${img.name}" loading="lazy" />
          </div>
        `).join('');

        document.getElementById('progress').textContent =
          `${images.length} images loaded`;

        eagle.log.info(`Loaded ${images.length} images`);

      } catch (error) {
        eagle.log.error('Failed to load images:', error);
        eagle.notification.show({
          title: 'Error',
          message: error.message,
          type: 'error'
        });
      }
    }

    function zoomIn() {
      currentZoom += 10;
      updateZoom();
    }

    function zoomOut() {
      currentZoom = Math.max(10, currentZoom - 10);
      updateZoom();
    }

    function resetZoom() {
      currentZoom = 100;
      updateZoom();
    }

    function updateZoom() {
      const container = document.getElementById('container');
      container.style.maxWidth = `${800 * (currentZoom / 100)}px`;
      document.getElementById('progress').textContent =
        `Zoom: ${currentZoom}%`;
    }

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
      if (e.ctrlKey || e.metaKey) {
        if (e.key === '=' || e.key === '+') {
          e.preventDefault();
          zoomIn();
        } else if (e.key === '-') {
          e.preventDefault();
          zoomOut();
        } else if (e.key === '0') {
          e.preventDefault();
          resetZoom();
        }
      }
    });

    // Load images on startup
    loadImages();
  </script>
</body>
</html>
```

---

## Background Service

A background service that monitors for new items.

### manifest.json

```json
{
  "id": "item-monitor",
  "name": "Item Monitor",
  "version": "1.0.0",
  "description": "Monitor new items added to library",
  "main": "background.js",
  "type": "background",
  "keywords": ["monitor", "background"]
}
```

### background.js

```javascript
// Background service - runs continuously

let itemCount = 0;

async function initialize() {
  eagle.log.info('Item Monitor started');

  // Get initial count
  const items = await eagle.item.getAll();
  itemCount = items.length;
  eagle.log.info(`Initial item count: ${itemCount}`);

  // Listen for item additions
  eagle.event.on('itemAdded', handleItemAdded);
}

function handleItemAdded(item) {
  itemCount++;

  eagle.log.info(`New item added: ${item.name}`);
  eagle.log.info(`Total items: ${itemCount}`);

  // Show notification
  eagle.notification.show({
    title: 'New Item Added',
    message: `${item.name} (Total: ${itemCount})`,
    type: 'info'
  });
}

// Start the service
initialize();
```

---

## Internationalization

Plugin with multi-language support.

### manifest.json

```json
{
  "id": "multilang-plugin",
  "name": "Multilang Plugin",
  "version": "1.0.0",
  "main": "index.html",
  "type": "window",
  "i18n": {
    "en": {
      "title": "Multilanguage Plugin",
      "greeting": "Hello",
      "button": "Click Me"
    },
    "zh-CN": {
      "title": "多语言插件",
      "greeting": "你好",
      "button": "点击我"
    },
    "ja": {
      "title": "多言語プラグイン",
      "greeting": "こんにちは",
      "button": "クリック"
    }
  }
}
```

### index.html

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Multilang Plugin</title>
</head>
<body>
  <h1 id="title"></h1>
  <p id="greeting"></p>
  <button id="btn"></button>

  <script>
    // Get current locale
    const locale = eagle.app.getLocale();
    eagle.log.info('Current locale:', locale);

    // Function to get translated text
    function t(key) {
      // Access i18n from manifest
      const i18n = require('./manifest.json').i18n;
      const currentLang = i18n[locale] || i18n['en'];
      return currentLang[key] || key;
    }

    // Update UI with translations
    document.getElementById('title').textContent = t('title');
    document.getElementById('greeting').textContent = t('greeting');
    document.getElementById('btn').textContent = t('button');

    document.getElementById('btn').addEventListener('click', () => {
      eagle.notification.show({
        message: t('greeting'),
        type: 'success'
      });
    });
  </script>
</body>
</html>
```

---

## Best Practices Summary

1. **Always check for empty selections**: Validate data before processing
2. **Use try-catch**: Handle errors gracefully
3. **Provide feedback**: Use notifications for user actions
4. **Log for debugging**: Use eagle.log for development
5. **Clean up listeners**: Remove event listeners when done
6. **Optimize performance**: Use lazy loading, debouncing
7. **Support i18n**: Internationalize from the start
8. **Follow UI guidelines**: Keep UI consistent with Eagle's design
9. **Test thoroughly**: Test with different data and edge cases
10. **Document your code**: Add comments for maintainability
