---
name: eagle-plugin
description: Develop Eagle plugins using official API. Use when creating Eagle plugins, working with Eagle API, or when user mentions Eagle plugin development, manifest.json, or Eagle application integration.
---

# Eagle Plugin Development

## Overview

This skill helps you develop plugins for Eagle (digital asset management application) using the official Eagle Plugin API. Eagle plugins are built with standard web technologies (HTML, CSS, JavaScript) and can access native Node.js APIs.

## Core Concepts

### Plugin Types

Eagle supports 4 plugin types:

1. **Window Plugin** - Opens a popup window when triggered
2. **Background Service Plugin** - Runs continuously in the background
3. **Format Extension Plugin** - Adds support for new file formats (thumbnails, previews)
4. **Inspector Extension Plugin** - Enhances the right-side information panel

### Technical Environment

- **Runtime**: Chromium 107 + Node.js 16
- **No CORS restrictions**: Can access any URL
- **Full Node.js support**: Access to native APIs and npm packages
- **Internationalization**: Built-in i18n support

## Plugin Structure

Every Eagle plugin must have this structure:

```
my-eagle-plugin/
├── manifest.json          (required - plugin configuration)
├── index.html            (required for window plugins)
├── main.js               (plugin logic)
├── styles.css            (styling)
└── package.json          (optional - for npm dependencies)
```

## Instructions

### Step 1: Create manifest.json

Always start by creating a `manifest.json` file with these required fields:

```json
{
  "id": "your-unique-plugin-id",
  "name": "Plugin Display Name",
  "version": "1.0.0",
  "description": "Plugin description",
  "author": "Your Name",
  "main": "index.html",
  "type": "window",
  "keywords": ["tag1", "tag2"]
}
```

**Required fields:**
- `id`: Unique identifier (lowercase, hyphens only)
- `name`: Display name shown in Eagle
- `version`: Semantic version (e.g., "1.0.0")
- `main`: Entry file (HTML for window plugins)
- `type`: Plugin type (window, background, format, inspector)

**Optional but recommended:**
- `description`: What the plugin does
- `author`: Creator name
- `keywords`: Tags for discoverability
- `icon`: Plugin icon path (relative to manifest)
- `i18n`: Internationalization configuration

### Step 2: Access Eagle API

Eagle API is available globally as `eagle` object. Common patterns:

```javascript
// Get selected items
eagle.item.getSelected().then(items => {
  console.log('Selected items:', items);
});

// Access current library
eagle.library.get().then(library => {
  console.log('Current library:', library);
});

// Show notification
eagle.notification.show({
  title: 'Success',
  message: 'Operation completed',
  type: 'success'
});

// Window operations
eagle.window.close();  // Close plugin window
eagle.window.resize(800, 600);  // Resize window
```

### Step 3: Handle User Interactions

Use standard web APIs combined with Eagle APIs:

```javascript
// Example: Process selected images
document.getElementById('process-btn').addEventListener('click', async () => {
  const items = await eagle.item.getSelected();

  // Filter for images only
  const images = items.filter(item => item.ext.match(/\.(jpg|png|gif)$/i));

  // Process images
  images.forEach(img => {
    console.log(`Processing: ${img.name}`);
    // Your logic here
  });

  // Show completion notification
  eagle.notification.show({
    title: 'Complete',
    message: `Processed ${images.length} images`
  });
});
```

### Step 4: Use Node.js APIs (if needed)

You can require Node.js modules directly:

```javascript
const fs = require('fs');
const path = require('path');

// Example: Read local file
fs.readFile('data.json', 'utf8', (err, data) => {
  if (err) throw err;
  console.log(JSON.parse(data));
});
```

### Step 5: Implement Error Handling

Always handle errors gracefully:

```javascript
async function safeGetItems() {
  try {
    const items = await eagle.item.getSelected();

    if (!items || items.length === 0) {
      eagle.notification.show({
        title: 'Warning',
        message: 'No items selected',
        type: 'warning'
      });
      return;
    }

    return items;
  } catch (error) {
    eagle.log.error('Failed to get items:', error);
    eagle.notification.show({
      title: 'Error',
      message: error.message,
      type: 'error'
    });
  }
}
```

## Best Practices

1. **Always check for selected items**: Verify items exist before processing
2. **Provide user feedback**: Use notifications for operations that take time
3. **Handle errors gracefully**: Log errors and show user-friendly messages
4. **Use internationalization**: Support multiple languages from the start
5. **Keep UI responsive**: Use async/await for API calls
6. **Log debugging info**: Use `eagle.log.debug()` for development
7. **Test with different data**: Test with various file types and edge cases
8. **Follow naming conventions**: Use descriptive IDs and names
9. **Optimize performance**: Lazy load resources, minimize API calls
10. **Document your code**: Add comments for complex logic

## Common Patterns

### Pattern 1: Get and Filter Items

```javascript
async function getImageItems() {
  const items = await eagle.item.getSelected();
  return items.filter(item =>
    ['jpg', 'png', 'gif', 'webp'].includes(item.ext.toLowerCase())
  );
}
```

### Pattern 2: Process with Progress

```javascript
async function processItems(items) {
  for (let i = 0; i < items.length; i++) {
    // Process item
    await processItem(items[i]);

    // Update progress
    eagle.notification.show({
      message: `Processing ${i + 1}/${items.length}`,
      type: 'info'
    });
  }
}
```

### Pattern 3: Dialog Confirmation

```javascript
async function confirmDelete() {
  const result = await eagle.dialog.showMessageBox({
    type: 'question',
    message: 'Are you sure you want to delete?',
    buttons: ['Yes', 'No']
  });

  return result.response === 0; // Returns true if "Yes"
}
```

## Available APIs

For detailed API documentation, see [api-reference.md](api-reference.md).

Main API categories:
- **item**: Access and manage items (files)
- **folder**: Work with folders
- **tag**: Manage tags
- **library**: Access library information
- **window**: Control plugin window
- **dialog**: Show dialogs
- **notification**: Display notifications
- **contextMenu**: Create context menus
- **clipboard**: Clipboard operations
- **app**: Application info and control
- **log**: Logging utilities
- **event**: Event handling

## Examples

For complete code examples, see [examples.md](examples.md).

## Development Workflow

1. **Create plugin structure**: Set up manifest.json and files
2. **Develop locally**: Use Eagle's "Import Local Project" for testing
3. **Debug**: Use DevTools (Ctrl+Shift+I) to debug
4. **Test thoroughly**: Test with different scenarios and data
5. **Package**: Prepare for distribution
6. **Publish**: Submit to Eagle Plugin Center (optional)

## Troubleshooting

**Plugin not showing up:**
- Check manifest.json syntax
- Verify `id` is unique
- Ensure `main` file exists

**API not working:**
- Confirm you're using `eagle` global object
- Check API method exists in documentation
- Handle promises correctly (use async/await)

**Permissions issues:**
- Eagle plugins have full access, no permission system
- Check file paths are absolute when accessing local files

## Additional Resources

- Official Documentation: https://developer.eagle.cool/plugin-api/zh-cn
- Community: Join Eagle developer community for support
